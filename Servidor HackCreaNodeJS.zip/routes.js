var controller = require('./controller');

exports.endpoints = [
	{method: 'GET', path: '/', config: {handler: function(request, reply){reply('Servidor Node JS HackCrea')}}}
    ,{method: 'POST', path: '/EMIT', config: controller.EMIT}
    ,{method: 'POST', path: '/LOGIN', config: controller.LOGIN}
    ,{method: 'POST', path: '/REGISTER', config: controller.REGISTER}
    ,{method: 'POST', path: '/REGISTER_ALERT', config: controller.REGISTER_ALERT}
    ,{method: 'POST', path: '/REGISTER_POSITION', config: controller.REGISTER_POSITION}    
    ,{method: 'POST', path: '/SAVEIMAGE', config: controller.SAVEIMAGE}
    ,{method: 'POST', path: '/SAVECONTACTOS', config: controller.SAVECONTACTOS}
    ,{method: 'POST', path: '/SAVEPATRON', config: controller.SAVEPATRON}
    ,{method: 'POST', path: '/SAVETIPOALERTA', config: controller.SAVETIPOALERTA}
    ,{method: 'POST', path: '/PRUEBA', config: controller.PRUEBA}
    ,{method: 'POST', path: '/SMS', config: controller.SMS}
    ,{method: 'POST', path: '/VOLUMEN', config: controller.VOLUMEN}
    ,{method: 'POST', path: '/LOGOUT', config: controller.LOGOUT}
    ,{method: 'POST', path: '/CHECKPASS', config: controller.CHECKPASS}
    ,{method: 'GET',  path: '/GETUSERIMAGES', config: controller.GETUSERIMAGES}
    ,{method: 'POST', path: '/GETALERTDATA', config: controller.GETALERTDATA}
    ,{method: 'GET',  path: '/FILE/{file}',  config: controller.FILE}
    ,{method: 'GET',  path: '/IMG1/{file}',  config: controller.IMG1}
    ,{method: 'GET',  path: '/IMG2/{file}',  config: controller.IMG2}
    ,{method: 'POST', path: '/GETIMAGES', config: controller.GETIMAGES}
    ,{method: 'POST', path: '/TRANSFORM', config: controller.TRANSFORM}
    
    
    

    
    
];
