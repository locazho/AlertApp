const fs = require('fs');
var server =require('./server.js');
var mysql = require('mysql');
var sha1 = require('sha1');
var base64Img = require('base64-img');
var imagenes=[];
var usuarios=[];
var URL="http://www.devsutils.com:8989";
var FileReader = require('filereader')
  , fileReader = new FileReader()
  ;
//SOCKETSESIONES
/*
GETSERVER.io.emit('NOTIFY_SOCKET',
                        {LETRA:request.payload.datosdireccion.DSNOMBRESCLIENTENVIO[0],
                        TITULO:request.payload.datosdireccion.DSNOMBRESCLIENTENVIO,
                        CONTENIDO:'Esta Comprando en el Puestecito',
                        MIN:'Ahora',
                        INTERVALO:7000,
                        HASH:request.payload.hash});
*/
//request._logger[0].request


exports.EMIT = {
                handler: function(request, reply) {
                 /* console.dir('ENDPOINTEMIT')
                  console.dir(request.payload)*/
                     server.io.emit(request.payload.EVENT,
                        request.payload);
                     reply({})

                }}
/*exports.LOGIN={
    handler: function(request, reply) {
        for(let i=0;i<usuarios.length;i++){
          if(usuarios[i].USUARIO==request.payload.U&&request.payload.P==usuarios[i].PASS){

            return reply(usuarios[i])
            console.dir(usuarios[i])
            break;
          }
        }
        return reply({"ERROR":"NO EXISTE"});
    }
}
exports.REGISTER={
    handler: function(request, reply) {
        let usuario={ID:request._logger[0].request,USUARIO:request.payload.U,CORREO:request.payload.M,PASS:request.payload.P,CONTACTOS:''}
        usuarios.push(usuario);
        console.dir(usuario)
        reply(usuario);
        
    }
}*/
exports.LOGIN={
    handler: function(request, reply) {
        server.connection.query(`call login(?,?)`,[request.payload.U,request.payload.P], function (error, results, fields) {
          if (results&&results[0]&&results[0][0]){
                reply(results[0][0])
          }else{
            reply({ERROR:'Usuario o Contraseña Incorrectos'})
          }
        });
    }
}
exports.REGISTER={
    handler: function(request, reply) {
        server.connection.query(`SELECT id,usuario,correo FROM usuarios WHERE usuario = ?`,
            [request.payload.U], function (error, results, fields) {
          if (results&&results[0]&&results[0].id){
                reply({ERROR:'EL usuario ya existe'});
          }else{
               server.connection.query(`SELECT id,usuario,correo FROM usuarios WHERE correo = ?`,
                [request.payload.M], function (error, results, fields) {
              if (results&&results[0]&&results[0].id){
                    reply({ERROR:'El correo ya existe'})
              }else{
                REGISTER_INSERT(request,reply)
              }
            });
          }
        });
    }
}
function REGISTER_INSERT(request,reply){
  server.connection.query(`INSERT INTO usuarios(usuario,password,nombres,apellidos,correo,tipo,rol,inicio,final,activo,activomail,tipoalerta,clicks,patron,contactos) VALUES (?,SHA1(?),?,?,?,'CREACION',?,NOW(),'4000-12-31',1,1,'BOTONES',3,'','')`,
            [request.payload.U,
            request.payload.P,
            request.payload.N,
            ""
            /*request.payload.A*/,
            request.payload.M,"1"/*
            request.payload.R*/], function (error, results, fields) {
          if (!error){
                reply(results)
          }else{
            reply({ERROR:'Error'})
          }
        });
}
exports.LOGOUT={
    handler: function(request, reply) {
        server.connection.query(`call logoutpass(?,?)`,
            [request.payload.H,request.payload.P], function (error, results, fields) {
          if (results&&results[0]&&results[0][0]){

                reply(results[0][0])
          }else{ reply({})
          }
        });
    }
}
exports.CHECKPASS={
    handler: function(request, reply) {
        server.connection.query(`call checkpass(?,?)`,
            [request.payload.H,request.payload.P], function (error, results, fields) {
          if (results&&results[0]&&results[0][0]){

                reply(results[0][0])
          }else{ reply({})
          }
        });
    }
}
exports.PRUEBA={
    handler: function(request, reply) {
        console.dir(request.payload)
        reply({"bien":"y vos"});
        
    }
}

exports.SAVEIMAGE={
    handler: function(request, reply) {
      let d =new Date();
      let NOMBRE= request.payload.ID+''+d.getFullYear()+''+(d.getMonth()+1)+''+d.getDate()+''+d.getHours()+''+d.getMinutes()+''+d.getSeconds()+''+d.getMilliseconds();
      try{
        base64Img.img(request.payload.I, 'FILES', NOMBRE, function(err, filepath) {

              if(err){
                reply({}) 
                console.dir(err)}else{

      server.connection.query(`INSERT INTO imagenes(relacion,usuario,fecha,latitud,longitud,imagen) VALUES (?,?,NOW(),?,?,?)`,
            [
            request.payload.A,
            request.payload.ID,
            request.payload.LAT,
            request.payload.LNG,
            `FILES/${NOMBRE}.png`], function (error, results, fields) {
          if (!error){
                reply({OK:"EXITO"})
          }else{
            reply({ERROR:'Error'})
          }
        });
              }
                    

        });
      }catch(e){
          reply({})
      }
      
    }
}

exports.SAVECONTACTOS={
    handler: function(request, reply) {
        server.connection.query(`call changecontacts(?,?)`,
            [request.payload.H,request.payload.C], function (error, results, fields) {
          if (results&&results[0]&&results[0][0]){

                reply(results[0][0])
          }else{ reply({})
          }
        });
        
    }
}
exports.SAVEPATRON={
    handler: function(request, reply) {
        server.connection.query(`call changepatron(?,?)`,
            [request.payload.H,request.payload.P], function (error, results, fields) {
          if (results&&results[0]&&results[0][0]){

                reply(results[0][0])
          }else{ reply({})
          }
        });
        
    }
}
exports.SAVETIPOALERTA={
    handler: function(request, reply) {
        server.connection.query(`call changealerta(?,?)`,
            [request.payload.H,request.payload.A], function (error, results, fields) {
          if (results&&results[0]&&results[0][0]){

                reply(results[0][0])
          }else{ reply({});
          }
        });
        
    }
}

exports.GETUSERIMAGES={
  handler: function(request, reply) {
    let IMAGES=[];
        for(let i=0;i<usuarios.length;i++){
          if(imagenes[i].IDUSUARIO==request.query.ID){
            IMAGES.push(imagenes[i])
          }
        }
        return reply(IMAGES);
    }
}
const twilio=require('twilio');
const accountSid = 'AC15f77441d9cbfbf604d2480b3b925715';
const authToken = 'f8f94ef9971b4f9ccd0a16fa635665f7';
const client = require('twilio')(accountSid, authToken);

exports.SMS={
    handler: function(request, reply) {
      if(request.payload.P&&request.payload.T){
          client.messages.create(
            {
              to: request.payload.P,
              from: '+14065100357',
              body: request.payload.T,
            },
            (err, message) => {
              if(!err){
                return reply({OK:message.sid});
              }else{
                return reply({ERROR:"FALLO"});
              }
              
            }
          );
      }
        
    }
}

exports.VOLUMEN={
    handler: function(request, reply) {
     console.dir(request.payload)
      reply({})
        
    }
}
const stream = require('stream');
exports.TRANSFORM={
    handler: function(request, reply) {
      reply(request.payload)
    }}

exports.GETALERTDATA={
    handler: function(request, reply) {
      server.connection.query(`call getalertpositions(?)`,
            [request.payload.ID], function (error, results, fields) {
          let DATA={'POSICIONES':[],'NOMBRE':''};
          if (results&&results[0]&&results[0][0]){
              DATA['POSICIONES']=results[0];
          }
          if (results&&results[1]&&results[1][0]){ 
            DATA['NOMBRE']=results[1][0].NOMBRE;
            
          }
          reply(DATA)
        });
      
    }
}
exports.FILE={
    handler:{
      file: function (request) {
            return 'FILES/'+request.params.file;
        }
      
    }
}
exports.IMG1={
    handler:{
      file: function (request) {
            return 'http://127.0.0.1:8080/live.jpg';
        }
      
    }
}
exports.IMG2={
    handler: function(request, reply) {
      reply().redirect('http://127.0.0.1:8080/live.jpg').header('Access-Control-Allow-Origin', '*').header('Access-Control-Allow-Origin', '*').header('Access-Control-Allow-Methods', 'GET,POST,PUT,HEAD,DELETE,OPTIONS').header('Access-Control-Allow-Headers', 'content-Type,x-requested-with');
      
    }
}
exports.GETIMAGES={
  handler: function(request, reply) {
    console.dir(request.payload)
          server.connection.query(`call getalertimages(?)`,
            [request.payload.ID], function (error, results, fields) {
          let DATA={'IMAGENES':[],'NOMBRE':''};
          if (results&&results[0]&&results[0][0]){
              DATA['IMAGENES']=results[0];
          }
          if (results&&results[1]&&results[1][0]){ 
            DATA['NOMBRE']=results[1][0].NOMBRE;
            
          }
          reply(DATA)
        });
    }
}

exports.REGISTER_ALERT={
  handler: function(request, reply) {
          let d =new Date();
          let ALERTID= request.payload.H+''+d.getFullYear()+''+(d.getMonth()+1)+''+d.getDate()+''+d.getHours()+''+d.getMinutes()+''+d.getSeconds()+''+d.getMilliseconds();
          server.connection.query(`INSERT INTO alertas(relacion,usuario,inicio,final,activo,tipoalerta,clicks,patron,contactos) VALUES (?,?,NOW(),'4000-12-31',1,?,?,?,?)`,
            [ALERTID,
            request.payload.I,
            request.payload.A,
            request.payload.C,
            request.payload.P,
            request.payload.CO], function (error, results, fields) {
          if (!error){
            
                reply({ID:ALERTID})
          }else{
            reply({ERROR:'Error'})
          }
        });
    }
}

exports.REGISTER_POSITION={
  handler: function(request, reply) {
          server.connection.query(`INSERT INTO posiciones(relacion,usuario,fecha,latitud,longitud) VALUES (?,?,NOW(),?,?)`,
            [
            request.payload.A,
            request.payload.I,
            request.payload.LAT,
            request.payload.LNG], function (error, results, fields) {
          if (!error){
            
                reply({OK:"EXITO"})
          }else{
           // console.dir(error)
            reply({ERROR:'Error'})
          }
        });
    }
}